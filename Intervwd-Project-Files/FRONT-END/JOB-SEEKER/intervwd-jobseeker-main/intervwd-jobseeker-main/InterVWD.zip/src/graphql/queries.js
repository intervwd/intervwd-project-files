/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const GetCurrentUserDetails = /* GraphQL */ `
  query GetCurrentUserDetails($input: GetCurrentUserDetailsInput) {
    GetCurrentUserDetails(input: $input)
  }
`;
export const ListJobDescriptions = /* GraphQL */ `
  query ListJobDescriptions($input: ListJobDescriptionsInput) {
    ListJobDescriptions(input: $input)
  }
`;
export const ListSearchJobDescriptionByJobCode = /* GraphQL */ `
  query ListSearchJobDescriptionByJobCode(
    $input: ListSearchJobDescriptionByJobCodeInput
  ) {
    ListSearchJobDescriptionByJobCode(input: $input)
  }
`;
export const ListTopUpCreditHistory = /* GraphQL */ `
  query ListTopUpCreditHistory($input: ListTopUpCreditHistoryInput) {
    ListTopUpCreditHistory(input: $input)
  }
`;
