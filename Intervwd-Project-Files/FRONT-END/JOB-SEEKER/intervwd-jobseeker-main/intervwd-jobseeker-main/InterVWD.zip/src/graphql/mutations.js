/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const UdpateMyDetails = /* GraphQL */ `
  mutation UdpateMyDetails($input: UdpateMyDetailsInput) {
    UdpateMyDetails(input: $input)
  }
`;
export const TopUpCredit = /* GraphQL */ `
  mutation TopUpCredit($input: TopUpCreditInput) {
    TopUpCredit(input: $input)
  }
`;
