import express from "express";
import http from "http";
import { Server } from "socket.io";
import fetch from "node-fetch";

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

io.on("connection", (socket) => {
  console.log("Client connected");

  socket.on("initializeConnection", async (ack) => {
    try {
      const res = await fetch(
        "https://ymyfc6k5s2.execute-api.us-east-1.amazonaws.com/Dev/getInterviewPrompt",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            command: "getInterviewPrompt",
            interview_id: "076a137b-2115-41d4-b1e3-ca6884201933",
          }),
        }
      );
      const data = await res.json();

      socket.emit("textOutput", { role: "ASSISTANT", content: data.prompt });
      ack({ success: true });
    } catch (e) {
      console.error(e);
      ack({ success: false, error: e.message });
    }
  });

  socket.on("disconnect", () => console.log("Client disconnected"));
});

server.listen(8080, () => {
  console.log("Server running on http://localhost:8080");
});
