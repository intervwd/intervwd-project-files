const { defineConfig } = require("@vue/cli-service");
module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave: false,
  devServer: {
    port: 8080, // 👈 change port here
  },

  pluginOptions: {
    vuetify: {
      // https://github.com/vuetifyjs/vuetify-loader/tree/next/packages/vuetify-loader
    },
  },
});

export default {
  server: {
    proxy: {
      "/socket.io": {
        target: "http://localhost:8080",
        ws: true,
      },
    },
  },
};
