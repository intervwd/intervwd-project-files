<template>
  <div>
    <v-dialog :model-value="PaymentDialog" max-width="600px" persistent>
      <v-card rounded="xl" class="pa-6">
        <!-- Title -->
        <div class="d-flex align-center mb-6">
          <v-icon color="primary" class="mr-2">mdi-credit-card-outline</v-icon>
          <h3 class="text-h6 font-weight-bold">Recharge Credits</h3>
        </div>

        <!-- Credit Packs -->
        <v-row dense>
          <v-col
            v-for="(pack, i) in creditPacks"
            :key="i"
            cols="6"
            class="mb-4"
          >
            <v-card
              variant="outlined"
              rounded="lg"
              class="d-flex flex-column align-center justify-center pa-6 text-center hover-card"
              :class="{ 'selected-card': selectedPack?.id === pack.id }"
              @click="selectPack(pack)"
            >
              <!-- Bonus Badge -->
              <!-- <div v-if="pack.bonus" class="bonus-badge">
                +{{ pack.bonus }} Bonus
              </div> -->

              <div class="font-weight-bold text-h6 mt-2">
                {{ pack.credits }}
              </div>
              <div class="text-caption text-grey-darken-1">credits</div>
              <div class="text-h6 text-BlueColorVariant2 mt-2">
                {{ pack.price }}
              </div>
              <!-- <div v-if="pack.save" class="mt-1 text-caption text-success">
                Save {{ pack.save }}
              </div> -->
            </v-card>
          </v-col>
        </v-row>

        <div
          class="mt-6 px-3"
          style="background-color: #f8fafc; border-radius: 10px"
        >
          <h4 class="text-body-1 font-weight-medium mt-1 mb-1">
            Payment Information
          </h4>
          <p class="text-caption text-grey mb-4">
            This is a demo UI. Payment gateway integration would be implemented
            here.
          </p>

          <v-text-field
            v-model="payment.card"
            label="Card Number"
            placeholder="1234 5678 9012 3456"
            variant="outlined"
            rounded="lg"
            density="compact"
            bg-color="white"
            prepend-inner-icon="mdi-credit-card"
          />

          <v-row>
            <v-col cols="6">
              <v-text-field
                v-model="payment.expiry"
                label="MM/YY"
                placeholder="MM/YY"
                variant="outlined"
                rounded="lg"
                bg-color="white"
                density="comfortable"
              />
            </v-col>
            <v-col cols="6">
              <v-text-field
                v-model="payment.cvv"
                label="CVV"
                placeholder="***"
                variant="outlined"
                rounded="lg"
                bg-color="white"
                density="comfortable"
              />
            </v-col>
          </v-row>
        </div>

        <!-- Actions -->
        <div class="d-flex justify-end mt-6">
          <v-btn
            variant="text"
            color="grey"
            class="mr-2"
            @click="paymentDialogEmit(1)"
          >
            Cancel
          </v-btn>
          <v-btn
            color="primary"
            class="px-6"
            :disabled="!selectedPack"
            @click="completePurchase"
          >
            Complete Purchase
          </v-btn>
        </div>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
export default {
  props: {
    PaymentDialog: Boolean,
  },
  data() {
    return {
      selectedPack: null,
      creditPacks: [
        { id: 1, credits: 1000, price: "$10", bonus: 5 },
        { id: 2, credits: 5000, price: "$40", save: "$5" },
        { id: 3, credits: 10000, price: "$60", bonus: 25, save: "$25" },
        { id: 4, credits: 50000, price: "$250", bonus: 75, save: "$75" },
      ],
      payment: {
        card: "",
        expiry: "",
        cvv: "",
      },
    };
  },
  methods: {
    selectPack(pack) {
      this.selectedPack = pack;
    },
    paymentDialogEmit(Toggle) {
      this.$emit("clicked", Toggle);
    },
    completePurchase() {
      alert(
        `Purchased ${this.selectedPack.credits} credits for ${this.selectedPack.price}`
      );
    },
  },
};
</script>

<style scoped>
.hover-card {
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
}
.hover-card:hover {
  background-color: #f9fafb;
}
.selected-card {
  border: 2px solid #1976d2;
  background-color: #eaf3ff;
}
.bonus-badge {
  position: absolute;
  top: 8px;
  right: 12px;
  background-color: #22c55e;
  color: white;
  font-size: 11px;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 12px;
}
</style>
