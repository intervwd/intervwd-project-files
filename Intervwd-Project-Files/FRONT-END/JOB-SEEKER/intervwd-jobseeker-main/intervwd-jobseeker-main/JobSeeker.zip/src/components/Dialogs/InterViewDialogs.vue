<template>
  <v-container fluid class="py-6">
    <!-- Status -->
    <div class="text-center mb-4">
      <h3 :class="statusClass">{{ status }}</h3>
    </div>

    <!-- Chat -->
    <v-card class="pa-4 chat-window elevation-1 rounded-lg">
      <div ref="chatContainer" class="chat-container">
        <div
          v-for="(msg, i) in chatHistory"
          :key="i"
          :class="['chat-bubble', msg.role.toLowerCase()]"
        >
          <div class="role-label">{{ msg.role }}</div>
          <div>{{ msg.message }}</div>
        </div>

        <!-- Listening indicator -->
        <div v-if="waitingForUser" class="chat-bubble user thinking">
          <div class="role-label">USER</div>
          <div class="thinking-text">
            Listening <span class="dot"></span><span class="dot"></span
            ><span class="dot"></span>
          </div>
        </div>

        <!-- Thinking indicator -->
        <div v-if="waitingForAssistant" class="chat-bubble assistant thinking">
          <div class="role-label">ASSISTANT</div>
          <div class="thinking-text">
            Thinking <span class="dot"></span><span class="dot"></span
            ><span class="dot"></span>
          </div>
        </div>
      </div>
    </v-card>

    <!-- Controls -->
    <div class="d-flex justify-center mt-4">
      <v-btn
        color="primary"
        rounded="lg"
        class="mx-2"
        :disabled="isStreaming"
        @click="startStreaming"
      >
        Start Streaming
      </v-btn>
      <v-btn
        color="error"
        rounded="lg"
        class="mx-2"
        :disabled="!isStreaming"
        @click="stopStreaming"
      >
        Stop Streaming
      </v-btn>
    </div>
  </v-container>
</template>

<script>
import { io } from "socket.io-client";
import { AudioPlayer } from "@/lib/play/AudioPlayer.js";
import { ChatHistoryManager } from "@/lib/util/ChatHistoryManager.js";

export default {
  name: "VoiceInterview",
  data() {
    return {
      socket: null,
      audioPlayer: new AudioPlayer(),
      audioContext: null,
      audioStream: null,
      processor: null,
      sourceNode: null,

      chatHistory: [],
      chatHistoryManager: null,

      status: "Disconnected ❌",
      statusClass: "disconnected",
      isStreaming: false,
      waitingForUser: false,
      waitingForAssistant: false,

      // Flags
      sessionInitialized: false,
      manualDisconnect: false,

      // Initial audio support
      initialAudioData: null,
      initialAudioSent: false,
      initialMessageShown: false,
      initialAudioChunkSize: 512,

      // Audio setup
      TARGET_SAMPLE_RATE: 16000,
      samplingRatio: 1,
      isFirefox: navigator.userAgent.toLowerCase().includes("firefox"),

      SYSTEM_PROMPT: "You are a friend. Keep responses short (2-3 sentences).",
    };
  },
  mounted() {
    this.initSocket();
    this.initAudio();
  },
  beforeUnmount() {
    if (this.socket) this.socket.disconnect();
    if (this.audioContext) this.audioContext.close();
  },
  methods: {
    /** ---------- SOCKET ---------- */
    initSocket() {
      this.socket = io("http://localhost:8080");

      this.chatHistoryManager = ChatHistoryManager.getInstance(
        { current: this.chatHistory },
        (newChat) => (this.chatHistory = [...newChat.history])
      );

      this.socket.on("connect", () => {
        this.status = "Connected ✅";
        this.statusClass = "connected";
      });

      this.socket.on("disconnect", () => {
        this.status = "Disconnected ❌";
        this.statusClass = "disconnected";
        this.isStreaming = false;
        this.sessionInitialized = false;
      });

      this.socket.on("textOutput", (data) => {
        if (data?.content) {
          this.addMessage(data.role, data.content);
          this.waitingForUser = data.role !== "USER";
          this.waitingForAssistant = data.role === "USER";
        }
      });

      this.socket.on("audioOutput", (data) => {
        if (data?.content) {
          const audioData = this.base64ToFloat32Array(data.content);
          this.audioPlayer.playAudio(audioData);
        }
      });
    },

    /** ---------- AUDIO ---------- */
    async initAudio() {
      try {
        this.status = "Requesting microphone 🎤...";
        this.statusClass = "connecting";

        this.audioStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });

        if (this.isFirefox) {
          this.audioContext = new AudioContext();
        } else {
          this.audioContext = new AudioContext({
            sampleRate: this.TARGET_SAMPLE_RATE,
          });
        }

        this.samplingRatio =
          this.audioContext.sampleRate / this.TARGET_SAMPLE_RATE;
        await this.audioPlayer.start();

        this.status = "Microphone ready 🎙️";
        this.statusClass = "ready";
      } catch (err) {
        this.status = "Mic error: " + err.message;
        this.statusClass = "error";
      }
    },

    async initializeSession() {
      if (this.sessionInitialized) return;
      this.status = "Initializing session...";
      const promptResponse = await fetch(
        "https://ymyfc6k5s2.execute-api.us-east-1.amazonaws.com/Dev/getInterviewPrompt",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            command: "getInterviewPrompt",
            interview_id: "076a137b-2115-41d4-b1e3-ca6884201933",
          }),
        }
      );
      const promptData = await promptResponse.json();

      this.SYSTEM_PROMPT = promptData.prompt || this.SYSTEM_PROMPT;

      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error("Timeout")), 5000);
        this.socket.emit("initializeConnection", (ack) => {
          clearTimeout(timeout);
          if (ack?.success) resolve();
          else reject(new Error("Connection failed"));
        });
      });

      this.socket.emit("promptStart");
      this.socket.emit("systemPrompt", this.SYSTEM_PROMPT);
      this.socket.emit("audioStart");

      this.sessionInitialized = true;
      this.status = "Session ready ✅";
      this.statusClass = "connected";
    },

    async startStreaming() {
      if (this.isStreaming) return;
      if (!this.audioStream) await this.initAudio();
      if (!this.sessionInitialized) await this.initializeSession();

      this.sourceNode = this.audioContext.createMediaStreamSource(
        this.audioStream
      );
      this.processor = this.audioContext.createScriptProcessor(512, 1, 1);

      this.processor.onaudioprocess = (e) => {
        if (!this.isStreaming) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7fff;
        }
        this.socket.emit(
          "audioInput",
          this.arrayBufferToBase64(pcmData.buffer)
        );
      };

      this.sourceNode.connect(this.processor);
      this.processor.connect(this.audioContext.destination);

      this.isStreaming = true;
      this.status = "Streaming... 🎧";
      this.statusClass = "recording";
      this.waitingForUser = true;
    },

    stopStreaming() {
      if (!this.isStreaming) return;

      this.isStreaming = false;
      if (this.processor) {
        this.processor.disconnect();
        this.sourceNode.disconnect();
      }

      this.audioPlayer.bargeIn();
      this.socket.emit("stopAudio");

      this.sessionInitialized = false;
      this.status = "Stopped. Click Start again.";
      this.statusClass = "ready";
      this.waitingForAssistant = false;
      this.waitingForUser = false;
    },

    /** ---------- HELPERS ---------- */
    addMessage(role, message) {
      this.chatHistory.push({ role, message });
      this.$nextTick(() => {
        const el = this.$refs.chatContainer;
        if (el) el.scrollTop = el.scrollHeight;
      });
    },
    arrayBufferToBase64(buffer) {
      return btoa(String.fromCharCode(...new Uint8Array(buffer)));
    },
    base64ToFloat32Array(base64String) {
      const binary = atob(base64String);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const int16Array = new Int16Array(bytes.buffer);
      return new Float32Array(int16Array.map((x) => x / 32768.0));
    },
  },
};
</script>
