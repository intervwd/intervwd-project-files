<template>
  <v-container class="pa-6 mx-3" fluid>
    <!-- <div class="mb-6 mt-n4">
      <h2 class="text-h6 font-weight-bold">Interview History</h2>
      <p class="text-body-2 text-medium-emphasis">
        View your completed interviews with transcripts and audio playback
      </p>
    </div>

    <v-data-table
      :headers="headers"
      :items="interviews"
      item-value="id"
      v-model:expanded="expanded"
      class="rounded-lg elevation-1 font-mono"
      density="comfortable"
      hide-default-footer
    >
      <template v-slot:[`item.action`]="{ item }">
        <v-btn
          size="small"
          color="GreenColorVariant1"
          variant="tonal"
          class="text-capitalize"
          @click="toggleExpand(item.id)"
        >
          <span class="fontsize12px">View Details</span>
          <v-icon right size="small">
            {{
              expanded.includes(item.id) ? "mdi-chevron-up" : "mdi-chevron-down"
            }}
          </v-icon>
        </v-btn>
      </template>

      <template v-slot:expanded-row="{ columns, item }">
        <tr>
          <td :colspan="columns.length" class="pa-4 bg-grey-lighten-3">
            <div class="mb-4">
              <h3 class="heading d-flex align-center mb-2">
                <v-icon class="mr-2" color="primary">mdi-volume-high</v-icon>
                Audio Recording
              </h3>
              <v-sheet class="pa-2 rounded-lg elevation-1">
                <audio controls style="width: 100%">
                  <source :src="item.audioUrl" type="audio/mp3" />
                  Your browser does not support the audio element.
                </audio>
              </v-sheet>
            </div>

            <div class="mt-2">
              <div class="heading d-flex align-center mb-2">
                <v-icon class="mr-2" color="green"
                  >mdi-file-document-outline</v-icon
                >
                Interview Transcript
              </div>
              <v-card outlined class="pa-4 rounded-lg">
                <div
                  v-for="(line, idx) in item.transcript"
                  :key="idx"
                  class="mb-3"
                >
                  <span class="font-weight-bold text-grey-darken-1"
                    >{{ line.speaker }}:
                  </span>
                  <span class="text-grey-darken-1">{{ line.text }}</span>
                </div>
              </v-card>
            </div>
          </td>
        </tr>
      </template>
    </v-data-table> -->
    <div class="text-center font-weight-bold fontsize30px">Coming Soon</div>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      expanded: [], // store expanded rows
      headers: [
        { title: "JOB ID", value: "id" },
        { title: "JOB TITLE", value: "title" },
        { title: "COMPANY", value: "company" },
        { title: "DATE", value: "date" },
        { title: "DURATION", value: "duration" },
        { title: "ACTION", value: "action", sortable: false },
      ],
      interviews: [
        {
          id: "JOB-2024-001",
          title: "Senior Frontend Developer",
          company: "TechCorp Inc.",
          date: "5/10/2025",
          duration: "4.5 min",
          audioUrl:
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
          transcript: [
            {
              speaker: "Interviewer",
              text: "Tell me about your experience with React.",
            },
            {
              speaker: "Candidate",
              text: "I have over 5 years of experience working with React...",
            },
          ],
        },
        {
          id: "JOB-2024-002",
          title: "Full Stack Engineer",
          company: "StartupXYZ",
          date: "3/10/2025",
          duration: "5 min",
          audioUrl:
            "https://file-examples.com/storage/fef5ec57e6d3c8578ef6b7e/2017/11/file_example_MP3_700KB.mp3",
          transcript: [
            {
              speaker: "Interviewer",
              text: "Tell me about your backend experience.",
            },
            {
              speaker: "Candidate",
              text: "I’ve worked with Node.js, Express, and MongoDB...",
            },
          ],
        },
      ],
    };
  },
  methods: {
    toggleExpand(id) {
      if (this.expanded.includes(id)) {
        this.expanded = this.expanded.filter((e) => e !== id);
      } else {
        this.expanded = [id]; // only one row open at a time
      }
    },
  },
};
</script>
