<template>
  <v-container class="py-6" fluid>
    <div class="text-center mb-4">
      <h3 :class="statusClass">{{ status }}</h3>
    </div>
    <v-card class="pa-4 chat-window elevation-1 rounded-lg">
      <div ref="chatContainer" class="chat-container">
        <div
          v-for="(msg, i) in chatHistory"
          :key="i"
          :class="['chat-bubble', msg.role.toLowerCase()]"
        >
          <div class="role-label">{{ msg.role }}</div>
          <div>{{ msg.message }}</div>
        </div>

        <div v-if="waitingForUser" class="chat-bubble user thinking">
          <div class="role-label">USER</div>
          <div class="thinking-text">
            Listening <span class="dot"></span><span class="dot"></span
            ><span class="dot"></span>
          </div>
        </div>

        <div v-if="waitingForAssistant" class="chat-bubble assistant thinking">
          <div class="role-label">ASSISTANT</div>
          <div class="thinking-text">
            Thinking <span class="dot"></span><span class="dot"></span
            ><span class="dot"></span>
          </div>
        </div>
      </div>
    </v-card>

    <div class="d-flex justify-center mt-4">
      <v-btn
        color="primary"
        rounded="lg"
        class="mx-2"
        :disabled="isStreaming"
        @click="startStreaming"
      >
        Start Streaming
      </v-btn>
      <v-btn
        color="error"
        rounded="lg"
        class="mx-2"
        :disabled="!isStreaming"
        @click="stopStreaming"
      >
        Stop Streaming
      </v-btn>
    </div>
  </v-container>
</template>

<script>
import { io } from "socket.io-client";
import { AudioPlayer } from "@/lib/play/AudioPlayer.js";
import { ChatHistoryManager } from "@/lib/util/ChatHistoryManager.js";

export default {
  name: "VoiceChat",
  data() {
    return {
      socket: null,
      chatHistory: [],
      audioContext: null,
      audioStream: null,
      processor: null,
      sourceNode: null,
      audioPlayer: new AudioPlayer(),
      chatHistoryManager: null,

      // state
      status: "Disconnected ❌",
      statusClass: "disconnected",
      isStreaming: false,
      sessionInitialized: false,

      // flags
      waitingForAssistant: false,
      waitingForUser: false,

      SYSTEM_PROMPT: "You are a friend. Keep responses short (2-3 sentences).",
      TARGET_SAMPLE_RATE: 16000,
      samplingRatio: 1,
      isFirefox: navigator.userAgent.toLowerCase().includes("firefox"),
    };
  },
  mounted() {},
  beforeUnmount() {
    if (this.socket) this.socket.disconnect();
  },
  methods: {
    initSocket() {
      this.socket = io("http://localhost:8080", {
        transports: ["websocket"],
      });

      this.chatHistoryManager = ChatHistoryManager.getInstance(
        { current: this.chatHistory },
        (newChat) => (this.chatHistory = [...newChat.history])
      );

      this.socket.on("connect", () => {
        this.status = "Connected ✅";
        this.statusClass = "connected";
      });

      this.socket.on("disconnect", () => {
        this.status = "Disconnected ❌";
        this.statusClass = "disconnected";
        this.isStreaming = false;
      });

      this.socket.on("error", (error) => {
        this.status = "Error: " + (error.message || "Unknown");
        this.statusClass = "error";
      });

      // textOutput from server
      this.socket.on("textOutput", (data) => {
        if (data?.content) {
          this.addMessage(data.role, data.content);
          this.waitingForUser = data.role !== "USER";
          this.waitingForAssistant = data.role === "USER";
        }
      });

      // audioOutput from server
      this.socket.on("audioOutput", (data) => {
        if (data?.content) {
          const audioData = this.base64ToFloat32Array(data.content);
          this.audioPlayer.playAudio(audioData);
        }
      });
    },

    /** ---------------- AUDIO ---------------- */
    async initAudio() {
      try {
        this.status = "Requesting microphone 🎤...";
        this.statusClass = "connecting";

        this.audioStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
        });

        if (this.isFirefox) {
          this.audioContext = new AudioContext();
        } else {
          this.audioContext = new AudioContext({
            sampleRate: this.TARGET_SAMPLE_RATE,
          });
        }

        this.samplingRatio =
          this.audioContext.sampleRate / this.TARGET_SAMPLE_RATE;

        await this.audioPlayer.start();
        this.status = "Microphone ready 🎙️";
        this.statusClass = "ready";
      } catch (err) {
        console.error("Mic access error:", err);
        this.status = "Mic error: " + err.message;
        this.statusClass = "error";
      }
    },

    async initializeSession() {
      if (this.sessionInitialized) return;
      this.status = "Initializing session...";

      try {
        const promptResponse = await fetch(
          "https://ymyfc6k5s2.execute-api.us-east-1.amazonaws.com/Dev/getInterviewPrompt",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              command: "getInterviewPrompt",
              interview_id: "076a137b-2115-41d4-b1e3-ca6884201933",
            }),
          }
        );
        const promptData = await promptResponse.json();

        console.log("AWS Prompt API Response:", promptData);
        this.initSocket();
        this.initAudio();
        // Use the prompt
        const SYSTEM_PROMPT =
          promptData.prompt ||
          "Default fallback prompt if API doesn't return one.";

        this.SYSTEM_PROMPT = SYSTEM_PROMPT;
        this.sessionInitialized = true;

        this.status = "Session initialized with AWS ✅";
        this.statusClass = "connected";
      } catch (err) {
        console.error("Failed to initialize session:", err);
        this.status = "Error initializing session";
        this.statusClass = "error";
      }
    },
    async startStreaming() {
      if (this.isStreaming) return;
      if (!this.audioStream) await this.initAudio();
      if (!this.sessionInitialized) await this.initializeSession();

      this.sourceNode = this.audioContext.createMediaStreamSource(
        this.audioStream
      );
      this.processor = this.audioContext.createScriptProcessor(512, 1, 1);

      this.processor.onaudioprocess = (e) => {
        if (!this.isStreaming) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7fff;
        }
        this.socket.emit(
          "audioInput",
          this.arrayBufferToBase64(pcmData.buffer)
        );
      };

      this.sourceNode.connect(this.processor);
      this.processor.connect(this.audioContext.destination);

      this.isStreaming = true;
      this.status = "Streaming... 🎧";
      this.statusClass = "recording";
      this.waitingForUser = true;
    },

    stopStreaming() {
      if (!this.isStreaming) return;
      this.isStreaming = false;

      if (this.processor) {
        this.processor.disconnect();
        this.sourceNode.disconnect();
      }

      this.audioPlayer.bargeIn();
      this.socket.emit("stopAudio");

      this.sessionInitialized = false;
      this.status = "Stopped. Click Start again.";
      this.statusClass = "ready";
      this.waitingForAssistant = false;
      this.waitingForUser = false;
    },

    /** ---------------- HELPERS ---------------- */
    addMessage(role, message) {
      this.chatHistory.push({ role, message });
      this.scrollChat();
    },
    scrollChat() {
      this.$nextTick(() => {
        const el = this.$refs.chatContainer;
        if (el) el.scrollTop = el.scrollHeight;
      });
    },
    arrayBufferToBase64(buffer) {
      return btoa(String.fromCharCode(...new Uint8Array(buffer)));
    },
    base64ToFloat32Array(base64String) {
      const binary = atob(base64String);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const int16Array = new Int16Array(bytes.buffer);
      return new Float32Array(int16Array.map((x) => x / 32768.0));
    },
  },
};
</script>

<style scoped>
.chat-window {
  height: 400px;
  overflow-y: auto;
  background: #f9fafb;
}
.chat-container {
  display: flex;
  flex-direction: column;
}
.chat-bubble {
  max-width: 70%;
  padding: 12px;
  border-radius: 12px;
  margin: 8px 0;
  font-size: 14px;
  line-height: 1.4;
}
.chat-bubble.user {
  align-self: flex-end;
  background: #dbeafe;
}
.chat-bubble.assistant {
  align-self: flex-start;
  background: #fecaca;
}
.role-label {
  font-size: 12px;
  font-weight: bold;
  margin-bottom: 4px;
}
.thinking-text {
  display: flex;
  align-items: center;
}
.dot {
  width: 6px;
  height: 6px;
  margin-left: 3px;
  background: #555;
  border-radius: 50%;
  animation: blink 1.4s infinite both;
}
.dot:nth-child(2) {
  animation-delay: 0.2s;
}
.dot:nth-child(3) {
  animation-delay: 0.4s;
}
@keyframes blink {
  0%,
  80%,
  100% {
    opacity: 0.2;
  }
  40% {
    opacity: 1;
  }
}
</style>
